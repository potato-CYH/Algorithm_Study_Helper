import React from 'react';

import "./GetCommonProblem.css";

function GetCommonProblem() {
    
    return (
        <div className="commonFrame">
            <div className="title">스터디 공통 문제 선별</div>

        </div>
    );
};

export default GetCommonProblem;